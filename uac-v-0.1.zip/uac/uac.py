#UAC No Cookies v 0.1
#programed by Majid AL-Maashari
#Email : omanras@gmail.com
#https://github.com/omanras



from bottle import route, run, template, static_file, get, post, request
import sqlite3 as sql
import hashlib


con = sql.connect("database.db")
cur = con.cursor()


    
@get('/static/admin/vendor/bootstrap/css/<filepath:re:.*\.css>')
def send_css1(filepath):
    return static_file(filepath, root='./admin/vendor/bootstrap/css')
@get('/static/admin/vendor/metisMenu/<filepath:re:.*\.css>')
def send_css2(filepath):
    return static_file(filepath, root='./admin/vendor/metisMenu')
@get('/static/admin/dist/css/<filepath:re:.*\.css>')
def send_css3(filepath):
    return static_file(filepath, root='./admin/dist/css/')
@get('/static/admin/vendor/morrisjs/<filepath:re:.*\.css>')
def send_css4(filepath):
    return static_file(filepath, root='./admin/vendor/morrisjs')
@get('/static/admin/vendor/font-awesome/css/<filepath:re:.*\.css>')
def send_css5(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/css/')
@get('/static/admin/vendor/font-awesome/css/<filepath:re:.*\.css>')
def send_css6(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/css/')

#js Files :
@get('/static/admin/vendor/jquery/<filepath:re:.*\.js>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/jquery')

@get('/static/admin/vendor/bootstrap/js/<filepath:re:.*\.js>')
def send_js2(filepath):
    return static_file(filepath, root='./admin/vendor/bootstrap/js')

@get('/static/admin/vendor/metisMenu/<filepath:re:.*\.js>')
def send_js3(filepath):
    return static_file(filepath, root='./admin/vendor/metisMenu')

@get('/static/admin/vendor/raphael/<filepath:re:.*\.js>')
def send_js4(filepath):
    return static_file(filepath, root='./admin/vendor/raphael/')

@get('/static/admin/vendor/morrisjs/<filepath:re:.*\.js>')
def send_js5(filepath):
    return static_file(filepath, root='./admin/vendor/morrisjs/')

@get('/static/admin/data/<filepath:re:.*\.js>')
def send_js6(filepath):
    return static_file(filepath, root='./admin/data/')

@get('/static/admin/dist/js/<filepath:re:.*\.js>')
def send_js7(filepath):
    return static_file(filepath, root='./admin/dist/js/')
@get('/static/admin/vendor/jquery/<filepath:re:.*\.js>')
def send_js8(filepath):
    return static_file(filepath, root='./admin/vendor/jquery')

#Fonts files :
@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.eot>')
def send_font1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')

@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.woff2>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')


@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.woff>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')


@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.svg>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')

@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.ttf>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')

@route('/')
def index():
    import socket

    error = "no"
    return template('index.tpl',error = error)

def index2(error):
    return template('index.tpl',error = error)    

@route('/logout')
def logout():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token :
        return index()
    if token == "not ok":
        return index()    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        id = str(users[0][0])
        token = "not ok"
        ip = "not ok"
        cur.execute("UPDATE users SET token = ? , ip = ? WHERE id = ?",(token , ip,id))
        con.commit()
        error = "no"
        return home(token,error)
    else:
       return index()
@route('/usersdelete-all')
@post('/usersdelete-all')
def deleteusers():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    token = request.query.token
    error = "no"
    userid = request.POST.getall('userid')
    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        userID = str(users[0][0])
        groupID = users[0][3]
        if not token :
            return home(token,error)
        if not userid :
            error = "no_userid"
            return deleteusers_error(error,token)
        else :    
 
            if users :
                if userID == groupID :
                    if userid > 0 :
                        for iduser in userid :
                            if str(iduser) == str(groupID) :
                                error = "no_admin"
                                return deleteusers_error(error,token)
                            else :    
                                cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(iduser,groupID)) 
                                con.commit()
                        error = "yes"
                        return deleteusers_error(error,token)        
    else :
        return index()                             
def deleteusers_error(error,token):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        return template('deleteusers-all.tpl',token = token ,error = error, users = users)
    else :
        return index()
@route('/userdelete')
def user_delete():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not token :
        return index()
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if users:
        if str(users[0][0]) == users[0][3]:
            if userid == str(users[0][3]):
                error = "admin_user"
                return user_deleteerror(error,token)
            else :
                groupID = users[0][3]
                cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(userid,groupID))
                con.commit()
                error = "yes"
                return user_deleteerror(error,token)             
        else :
            return home(token,error)        
    else :
        return index()            
def user_deleteerror(error,token):
    
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')

    if not token :
        return index()
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()        
    if users :
        if str(users[0][0]) == users[0][3]:
            return template('deleteusers-all.tpl',token = token ,error = error, users = users)
        else :
            error = "no"
            return home(token,error)   

    else :
        return index()    
@route('/users')
def users():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            return template('users.tpl',token = token,error = error,users = users)
    else :
        return index()        
@post('/users')

def adduser():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    groupID = users[0][3]
    groupName = users[0][5]

    if str(users[0][0]) == users[0][3]:

        username = request.forms.get('user')
        password = request.forms.get('password')
        email = request.forms.get('email')
        if not username :
            error = "no_user"
            return adduser_error(error,token)
        if not password :
            error = "no_password"
            return adduser_error(error,token)
        if not email :
            error = "no_email"
            return adduser_error(error,token) 
        else :
            cur.execute("SELECT username FROM users WHERE username = ?",[username])
            users = cur.fetchall()
            if users :
                error = "used_user"
                return adduser_error(error,token)
            cur.execute("SELECT email FROM users WHERE email = ?",[email])  
            users = cur.fetchall()
            if users :
                error = "used_email"
                return adduser_error(error,token)  
            else :

                password = hashlib.md5(password).hexdigest()
                tokenpass = "not ok"
                
                
                   
                cur.execute("INSERT INTO users (username,password,groupID,email,groupName,token) VALUES (?,?,?,?,?,?)",(username,password,groupID,email,groupName,tokenpass))
                con.commit()
                
                error = "yes"
                return adduser_error(error,token)
    else :
        return home(token,error)
def adduser_error(error,token):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()


    if str(users[0][0]) == users[0][3]:
        return template('users.tpl',error = error,token = token,users = users)
@route('/groupedit')
def group_name():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not token:
        return index()
    if not ip :
        return index()
    if not userid :
        return home(token,error)
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[userid])
            usersinfo = cur.fetchall()
            if usersinfo :
                return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
            else :
                return home(token,error)    

    else :
        return home(token,error)
@post('/groupedit')
def group_name_change():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    groupname = request.forms.get('groupname')
    error = "no"
    if not token:
        return index()
    if not ip :
        return index()
    if not userid :
        return home(token,error)
   
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":

            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[userid])
            usersinfo = cur.fetchall()
            if usersinfo :
                if not groupname :
                    error = "no_name"
                    return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
                cur.execute("SELECT groupName FROM users WHERE groupName = ?",[groupname])
                groupcheck = cur.fetchall()
                if groupcheck :
                    error = "group_used"
                    return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
                else :    
                    cur.execute("UPDATE users SET groupName = ? WHERE groupID = ?",(groupname,userid))
                    con.commit()
                    error = "yes"
                    return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
            else :
                return home(token,error)    

    else :
        return home(token,error)

@route('/adduser-group')
def adduser_group():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :    
        if str(users[0][0]) == "1" :
            cur.execute("SELECT groupName FROM users WHERE groupID = ?",[userid])
            group_name = cur.fetchall()
            groupname = str(group_name[0][0])
            return template('adduser-group.tpl',users = users,userid = userid ,error = error,token = token,groupname = groupname)
        else :
            return home(token,error)
    else :
        return home(token,error)       

@post('/adduser-group')
def adduser_group_admin():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token.error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()

    if str(users[0][0]) == "1":

        username = request.forms.get('user')
        password = request.forms.get('password')
        email = request.forms.get('email')
        cur.execute("SELECT groupName FROM users WHERE groupID = ?",[userid])
        group_name = cur.fetchall()
        groupname = group_name[0][0]
        if not username :
            error = "no_user"
            return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
        if not password :
            error = "no_password"
            return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
        if not email :
            error = "no_email"
            return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)

        else :
            cur.execute("SELECT username FROM users WHERE username = ?",[username])
            userscheck = cur.fetchall()
            if userscheck :
                error = "used_user"
                return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
            cur.execute("SELECT email FROM users WHERE email = ?",[email])  
            userscheck = cur.fetchall()
            if userscheck :
                error = "used_email"
                return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname) 
            else :

                password = hashlib.md5(password).hexdigest()
                tokenpass = "not ok"
                
                
                   
                cur.execute("INSERT INTO users (username,password,groupID,email,groupName,token) VALUES (?,?,?,?,?,?)",(username,password,userid,email,groupname,tokenpass))
                con.commit()
                
                error = "yes"
                return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)

    else :
        return home(token,error)

@route('/usersdelete-all-group')
@post('/usersdelete-all-group')
def usersdelete_all_group():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    userid = request.POST.getall('userid')
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()

    if str(users[0][0]) == "1":
        userID = str(users[0][0])
        
        if not token :
            return home(token,error)
        if not userid :
            error = "no_userid"
            return deleteusers_error(error,token)
        else :    
 
            if users :
                if userID == "1" :
                    if userid > 0 :
                        for iduser in userid :
                            if str(iduser) == str(groupID) :
                                error = "no_admin"
                                return deleteusers_error(error,token)
                            else :    
                                cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(iduser,groupID)) 
                                con.commit()
                        error = "yes_group"
                        return deleteusers_error(error,token)
    else :
        return home(token,error)                        
@route('/userdelete-gorup')
def userdelete_gorup():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    userid = request.query.userid
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()

    if str(users[0][0]) == "1":
        userID = str(users[0][0])
        
        if not token :
            return home(token,error)
        if not userid :
            error = "no_userid"
            return deleteusers_error(error,token)
        else :    
 
            if users :
                if userID == "1" :
                
                        
                    if userid == str(groupID) :
                        error = "no_admin"
                        return deleteusers_error(error,token)
                    else :    
                        cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(userid,groupID)) 
                        con.commit()
                        error = "yes_group"
                        return deleteusers_error(error,token)
    else :
        return home(token,error)        
@route('/changeadmin-group')
def changeadmin_group():

    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            
            return template('changeadmin-group.tpl',token = token,users = users,usersinfo = usersinfo,error = error)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@post('/changeadmin-group')
def change_admin():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    userid = request.forms.get('userid')
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if not userid :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)
    if userid == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            cur.execute("UPDATE users SET groupID = ? WHERE groupID = ?",(userid,groupID))
            con.commit()
            error = "yes"           
            return template('changeadmin-group.tpl',token = token,users = users,usersinfo = usersinfo,error = error)
        else :
            return home(token,error)    
    else :
        return home(token,error)    
@route('/group-delete')
def group_delete():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT groupName FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()    
            
            return template('group-delete.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@post('/group-delete')
def delete_group() :
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    error = "no"
    check = request.forms.get("check")

    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)
    if not check :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT groupName FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            if check == "yes" :
                cur.execute("DELETE FROM users WHERE groupID = ?",[groupID])
                con.commit()
                error = "yes"
                return template('group-delete.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo)
            else :
                return home(token,error)    
        else :
            return home(token,error)    
    else :
        return home(token,error)    
@route('/userinfo')
def userinfo():

    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()

    if users :
        groupID = users[0][3]
        groupName = users[0][5]
        return template('userinfo.tpl',token = token, error = error,users = users)
    else:
        return index()    

@post('/userinfo')
def userinfo_update():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()    
    if users:
        
        groupID = users[0][3]
        groupName = users[0][5]
        passwordcheck = users[0][2]
        username = request.forms.get('user')
        password = request.forms.get('password')
        email = request.forms.get('email')
        if not username :
            error = "no_user"
            return userinfo_error(error,token)
        if not password :
            error = "no_password"
            return userinfo_error(error,token)
        if not email :
            error = "no_email"
            return userinfo_error(error,token) 
        else :
            if username == users[0][1] and email == users[0][4]:
                password = hashlib.md5(password).hexdigest()
                cur.execute("UPDATE users SET password = ? WHERE token = ? and username = ?",(password,token,username))
                con.commit()
                error = "yes"
                return userinfo_error(error,token)
            if users[0][1] != username:

                cur.execute("SELECT username,password FROM users WHERE username = ?",[username])
                users = cur.fetchall()
                if users :
                    error = "used_user"
                    return userinfo_error(error,token)
                else :
                    password = hashlib.md5(password).hexdigest()
                    
                    if password == passwordcheck :
                        cur.execute("UPDATE users SET username = ? WHERE token = ? and password = ?",(username,token,password))
                        con.commit()
                        error = "yes"
                        return userinfo_error(error,token)
                    else :
                        error = "wrong_password"
                        return userinfo_error(error,token)    
            if users[0][4] != email :
                cur.execute("SELECT email,password FROM users WHERE email = ?",[email])  
                users = cur.fetchall() 
                if users :
                    error = "used_email"
                    return userinfo_error(error,token)
                else :
                    password = hashlib.md5(password).hexdigest()
                    
                    if password == passwordcheck :
                        cur.execute("UPDATE users SET email = ? WHERE token = ? and password = ?",(email,token,password))
                        con.commit()
                        error = "yes"
                        return userinfo_error(error,token)
                    else :
                        error = "wrong_password"
                        return userinfo_error(error,token)  
            else :


                return home(token,error)
        #else :
         #   return home(token,error)
    else :
        return index()       
def userinfo_error(error,token):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()


    if users :
        return template('userinfo.tpl',error = error,token = token,users = users)
    else:
        return home(token,error)    
@route('/useredit')
def useredit():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id

    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()    
    if users:
        if str(users[0][0]) == str(users[0][3]):
            groupID = users[0][3]
            cur.execute("SELECT id,username,email FROM users WHERE id = ? AND groupID = ?",(userid,groupID))
            usersinfo = cur.fetchall()
            return template('useredit.tpl',userid = userid,users = users,usersinfo = usersinfo,token = token,error = error)
        else :
            return home(token,error)   
    else :
        return index()


@post('/useredit')
def userinfo_update():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()    
    if users:
        if str(users[0][0]) == users[0][3]:

            groupID = users[0][3]
            groupName = users[0][5]
            #passwordcheck = users[0][2]
            username = request.forms.get('user')
            password = request.forms.get('password')
            email = request.forms.get('email')
            cur.execute("SELECT * FROM users WHERE id = ? AND groupID = ?",(userid,groupID))
            usersinfo = cur.fetchall()
            if usersinfo :
                if not username :
                    error = "no_user"
                    return useredit_error(error,token,userid)
                #if not password :
                #    error = "no_password"
                #   return userinfo_error(error,token)
                if not email :
                    error = "no_email"
                    return useredit_error(error,token,userid) 
                else :
                    if username == usersinfo[0][1] and email == usersinfo[0][4]:
                        if not password :
                            error = "no_password"
                            return useredit_error(error,token,userid)
                        password = hashlib.md5(password).hexdigest()
                        cur.execute("UPDATE users SET password = ? WHERE id = ? and username = ?",(password,userid,username))
                        con.commit()
                        error = "yes"
                        return useredit_error(error,token,userid)
                    if usersinfo[0][1] != username:

                        cur.execute("SELECT username FROM users WHERE username = ?",[username])
                        usersinfo = cur.fetchall()
                        if usersinfo :
                            error = "used_user"
                            return useredit_error(error,token,userid)
                        else :
                            #password = hashlib.md5(password).hexdigest()
                    
                            #if password == passwordcheck :
                            cur.execute("UPDATE users SET username = ? WHERE id = ? and groupID = ?",(username,userid,groupID))
                            con.commit()
                            error = "yes"
                            return useredit_error(error,token,userid)
                            #else :
                             #   error = "wrong_password"
                              #  return userinfo_error(error,token)    
                    if usersinfo[0][4] != email :
                        cur.execute("SELECT email FROM users WHERE email = ?",[email])  
                        usersinfo = cur.fetchall() 
                        if usersinfo :
                            error = "used_email"
                            return useredit_error(error,token,userid)
                        else :
                            #password = hashlib.md5(password).hexdigest()
                    
                            #if password == passwordcheck :
                            cur.execute("UPDATE users SET email = ? WHERE id = ? and groupID = ?",(email,userid,groupID))
                            con.commit()
                            error = "yes"
                            return useredit_error(error,token,userid)
                            #else :
                             #   error = "wrong_password"
                              #  return userinfo_error(error,token)  
                    else :
                        return home(token,error)
            else :
                return home(token,error)        
    else :
        return index()    
def useredit_error(error,token,userid) :
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index() 
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()


    if users :
        groupID = str(users[0][3])
        cur.execute("SELECT id,username,email FROM users WHERE id = ? AND groupID = ?",(userid,groupID))
        usersinfo = cur.fetchall()
        return template('useredit.tpl',error = error,token = token,users = users,userid = userid,usersinfo = usersinfo)
    else:
        return home(token,error)
@route('/userscp')
def userscp():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            return template('userscp.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
        else :
            return home(token,error)
    else :
        return index()       
@route('/creategroup')
def creategroup():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == "1":
            return template('creategroup.tpl',token = token,error = error, users = users)
        else :
            return home(token,error)
    else :
        return index()       
@post('/creategroup')
def addgroup():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    #groupID = users[0][3]
    #groupName = users[0][5]
    if users :

        if str(users[0][0]) == "1":
            groupname = request.forms.get('groupname')
            username = request.forms.get('user')
            password = request.forms.get('password')
            email = request.forms.get('email')
            if not groupname :
                error = "no_group"
                return addgroup_error(error,token)
            if not username :
                error = "no_user"
                return addgroup_error(error,token)
            if not password :
                error = "no_password"
                return addgroup_error(error,token)
            if not email :
                error = "no_email"
                return addgroup_error(error,token) 
            else :
                cur.execute("SELECT groupName FROM users WHERE groupName = ?",[groupname])
                users = cur.fetchall()
                if users :
                    error = "used_group"
                    return addgroup_error(error,token)
                cur.execute("SELECT username FROM users WHERE username = ?",[username])
                users = cur.fetchall()
                if users :
                    error = "used_user"
                    return addgroup_error(error,token)
                cur.execute("SELECT email FROM users WHERE email = ?",[email])  
                users = cur.fetchall()
                if users :
                    error = "used_email"
                    return addgroup_error(error,token)  
                else :

                    password = hashlib.md5(password).hexdigest()
                    tokenpass = "not ok"
                    #tokenpass = hashlib.md5(token).hexdigest()
                
                   
                    cur.execute("INSERT INTO users (username,password,email,groupName,token) VALUES (?,?,?,?,?)",(username,password,email,groupname,tokenpass))
                    con.commit()
                    cur.execute("SELECT id FROM users WHERE username = ? and password = ? and groupName = ?",(username,password,groupname))
                    users = cur.fetchall()
                    id = str(users[0][0])
                    groupID = str(users[0][0])
                    if users:
                        cur.execute("UPDATE users SET groupID = ? WHERE id = ?",(groupID,id))
                        con.commit()
                    #return template('home.tpl',token = token)
                        error = "yes"
                        return addgroup_error(error,token)
                    else:
                        return home(token,error)    
        else :
            return home(token,error)
    else :
        return index()        
def addgroup_error(error,token):

    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()



    if str(users[0][0]) == "1":
        return template('creategroup.tpl',error = error,token = token,users = users)
    else :
        return home(token,error)    
@route('/groups-manage')
def groups_manage():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE id = groupID")
            groupusers = cur.fetchall()
            return template('groups-manage.tpl',users = users ,groupusers = groupusers,token = token)
        else :
            return home(token,error)   
    else :
        return home(token,error)        
    
    cur.execute("")
@route('/home')
def home(token,error):
    #token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token:
        return index()
    if token == "not ok" :
        return index()
    else :    
        cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
        users = cur.fetchall()
    if error == "no" :
        if users :
           if str(users[0][7]) == ip : 
            return template('home.tpl',token = token,users = users)
           else :
            return index()   
    else :
        return index2(error)
@get('/home')
def gethome():
    #token = request.query.token
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token:
        return index()
    if token == "not ok":
        return index()
    error = "no"
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        return home(token,error)
    else :
        return index()        
    #return template('users.tpl',token = token)

    #return template('/users.tpl',token = token)

@post('/login')
def login():

   error = "no"
   username = request.forms.get('user')
   password = request.forms.get('password')
   ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
   if not ip :
       return index()
   #client_ip = request.environ.get('HTTP_X_FORWARDED_FOR')
   #print client_ip  
   print ip
   if not username :
       error = "no_user"
   if not password :
       error = "no_password"
   if error == "no" :

       password = hashlib.md5(password).hexdigest()
       #data = (username,password)
       con = sql.connect("database.db")
       cur = con.cursor()
       cur.execute("SELECT * FROM users WHERE username = ? and password = ?",(username,password))
       users = cur.fetchall()
       if users:

          userID = str(users[0][0])
          #token = users[0][6]
          token = password + username
          token = hashlib.md5(token).hexdigest()
          groupID = users[0][3]
          groupName = users[0][5]
          cur.execute("UPDATE users SET token = ? , ip = ? WHERE id = ?",(token,ip,userID))
          con.commit()
          return home(token,error)
       else :
           return index()   
   else :
       return index2(error)
           
 
 

#server run :
run(host='localhost', port=8080)